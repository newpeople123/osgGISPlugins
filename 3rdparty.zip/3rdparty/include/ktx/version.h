/*
// [API version]
@par API Version
v4.0
// [API version]
// [Code version]
v4.0
// [Code version]
*/
#define LIBKTX_VERSION v4.0
#define LIBKTX_DEFAULT_VERSION v4.0.__default__
